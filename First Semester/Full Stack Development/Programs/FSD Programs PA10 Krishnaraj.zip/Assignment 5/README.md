# [Images-Searcher](https://searchimagesplease.surge.sh)

A place to search for images that I can use in my powerpoint presentations, and other designs, from free and creditable sources and their APIs.

# Installation for Playing Around

1. Clone this repo
2. Install the dependencies with node.
3. Mess around.
4. Or just head over to [The deployed website](https://searchimagesplease.surge.sh)

# Screenshots

![](https://github.com/KrishnarajT/Images-Searcher/blob/main/Screenshots/ss.png)

# Credits

The Credits to this whole thing must go to the dude whose course I am watching to learn react from. [This is their Github Repo](https://github.com/OakAcademy). Excellent teacher. His courses are definitely recommended. Huge Thanks!
